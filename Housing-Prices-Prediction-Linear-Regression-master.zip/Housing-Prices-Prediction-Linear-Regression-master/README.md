# Housing-Prices-Prediction
This repository contains the code Matlab code for prediction of hosing prices using Linear Regression. We will use one feature and multiple features. All codes are written in Matlab Programming Language
